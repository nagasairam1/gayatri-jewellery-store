"use client";

import { useParams } from "next/navigation";
import Image from "next/image";

const productData = {
  "gold-ring": {
    name: "Gold Plated Ring",
    image: "/ring1.jpg",
    price: "₹1,999",
    description: "A timeless gold-plated ring perfect for all occasions."
  },
  "silver-necklace": {
    name: "Silver Heart Necklace",
    image: "/necklace1.jpg",
    price: "₹2,499",
    description: "A delicate silver necklace with a heart pendant."
  }
};

export default function ProductDetailPage() {
  const params = useParams();
  const slug = params?.slug;
  const product = productData[slug as keyof typeof productData];

  if (!product) {
    return <div className="text-center py-20">Product not found.</div>;
  }

  return (
    <main className="max-w-4xl mx-auto py-12 px-4">
      <div className="grid md:grid-cols-2 gap-10">
        <Image src={product.image} alt={product.name} width={500} height={500} className="rounded-lg" />
        <div>
          <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
          <p className="text-pink-600 text-2xl font-semibold mb-4">{product.price}</p>
          <p className="mb-6">{product.description}</p>
          <button className="bg-pink-600 text-white px-6 py-2 rounded hover:bg-pink-700">Add to Cart</button>
        </div>
      </div>
    </main>
  );
}