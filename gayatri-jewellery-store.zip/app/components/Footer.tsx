export default function Footer() {
  return (
    <footer className="bg-gray-100 text-center text-sm text-gray-600 py-6 mt-20">
      © 2025 Gayatri Jewellery. All rights reserved.
    </footer>
  );
}